﻿
namespace AdminPage
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sensorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.S_Start = new System.Windows.Forms.ToolStripMenuItem();
            this.S_Stop = new System.Windows.Forms.ToolStripMenuItem();
            this.S_AddNewSensor = new System.Windows.Forms.ToolStripMenuItem();
            this.S_Save = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.b_dataCollection_status = new System.Windows.Forms.Button();
            this.b_stop = new System.Windows.Forms.Button();
            this.b_start = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.b_save = new System.Windows.Forms.Button();
            this.b_addSensor = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.panel7 = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel_left = new System.Windows.Forms.Panel();
            this.panel_right = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.listView1_thp = new System.Windows.Forms.ListView();
            this.columnHeader0 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sPortNumber = new System.Windows.Forms.TextBox();
            this.l_port = new System.Windows.Forms.Label();
            this.sIPAddress = new System.Windows.Forms.TextBox();
            this.l_ipAddress = new System.Windows.Forms.Label();
            this.s_p250HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p250HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p250LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p250LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.particle250 = new System.Windows.Forms.CheckBox();
            this.l_p25 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.sID = new System.Windows.Forms.TextBox();
            this.l_zone = new System.Windows.Forms.Label();
            this.sZone = new System.Windows.Forms.TextBox();
            this.s_p100HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p100HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p100LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p100LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p50HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p50HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p50LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p50LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p30HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p30HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p30LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p30LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p10HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p10HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p10LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p10LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p05HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p05HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p05LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p05LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p01HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p03HigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p01HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p03HigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p01LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p03LowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_p01LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_p03LowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_hLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_hLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_hHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_hHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_tLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_tLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_tHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_tHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.particle100 = new System.Windows.Forms.CheckBox();
            this.particle50 = new System.Windows.Forms.CheckBox();
            this.particle30 = new System.Windows.Forms.CheckBox();
            this.particle10 = new System.Windows.Forms.CheckBox();
            this.l_p100Usage = new System.Windows.Forms.Label();
            this.l_p5Usage = new System.Windows.Forms.Label();
            this.l_p30Usage = new System.Windows.Forms.Label();
            this.l_p10Usage = new System.Windows.Forms.Label();
            this.l_p05Usage = new System.Windows.Forms.Label();
            this.l_p01 = new System.Windows.Forms.Label();
            this.particle05 = new System.Windows.Forms.CheckBox();
            this.particle01 = new System.Windows.Forms.CheckBox();
            this.l_p03Usage = new System.Windows.Forms.Label();
            this.particle03 = new System.Windows.Forms.CheckBox();
            this.l_hUsage = new System.Windows.Forms.Label();
            this.humidity = new System.Windows.Forms.CheckBox();
            this.l_tUsage = new System.Windows.Forms.Label();
            this.temperature = new System.Windows.Forms.CheckBox();
            this.l_sHigherLimit2 = new System.Windows.Forms.Label();
            this.l_sHigherLimit1 = new System.Windows.Forms.Label();
            this.l_sLowerLimit2 = new System.Windows.Forms.Label();
            this.l_sLowerLimit1 = new System.Windows.Forms.Label();
            this.l_sUsage = new System.Windows.Forms.Label();
            this.l_sDescription = new System.Windows.Forms.Label();
            this.l_sLocation = new System.Windows.Forms.Label();
            this.l_sName = new System.Windows.Forms.Label();
            this.l_sID = new System.Windows.Forms.Label();
            this.sDescription = new System.Windows.Forms.TextBox();
            this.sLocation = new System.Windows.Forms.TextBox();
            this.sName = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.listView2_pressure = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker2_p = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1_p = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.s_inchhgHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_inchhgHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_inchhgLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_inchhgLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_mmhgHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_mmhgHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_mmhgLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_mmhgLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_inchh2oHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_inchh2oHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_inchh2oLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_inchh2oLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_mmh2oHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_mmh2oHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_mmh2oLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_mmh2oLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_kpaHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_kpaHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_kpaLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_kpaLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_mbarLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_hpaLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_mbarLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_hpaLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_mbarHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_mbarHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_hpaHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_hpaHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_paLowerLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_paLowerLimit1 = new System.Windows.Forms.NumericUpDown();
            this.s_paHigherLimit2 = new System.Windows.Forms.NumericUpDown();
            this.s_paHigherLimit1 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.sID_p = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.sZone_p = new System.Windows.Forms.TextBox();
            this.inchhg = new System.Windows.Forms.CheckBox();
            this.mmhg = new System.Windows.Forms.CheckBox();
            this.inchh2o = new System.Windows.Forms.CheckBox();
            this.mmh2o = new System.Windows.Forms.CheckBox();
            this.mbar = new System.Windows.Forms.CheckBox();
            this.kpa = new System.Windows.Forms.CheckBox();
            this.hpa = new System.Windows.Forms.CheckBox();
            this.pa = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.sDescription_p = new System.Windows.Forms.TextBox();
            this.sLocation_p = new System.Windows.Forms.TextBox();
            this.sName_p = new System.Windows.Forms.TextBox();
            this.pTrackerTimer = new System.Windows.Forms.Timer(this.components);
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03HigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03HigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03LowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03LowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tHigherLimit1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaHigherLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paLowerLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paLowerLimit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paHigherLimit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paHigherLimit1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.sensorToolStripMenuItem,
            this.aboutToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            resources.ApplyResources(this.fileToolStripMenuItem, "fileToolStripMenuItem");
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            resources.ApplyResources(this.exitToolStripMenuItem, "exitToolStripMenuItem");
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.F_Exit_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.cutToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            resources.ApplyResources(this.editToolStripMenuItem, "editToolStripMenuItem");
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            resources.ApplyResources(this.copyToolStripMenuItem, "copyToolStripMenuItem");
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            resources.ApplyResources(this.pasteToolStripMenuItem, "pasteToolStripMenuItem");
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            resources.ApplyResources(this.cutToolStripMenuItem, "cutToolStripMenuItem");
            // 
            // sensorToolStripMenuItem
            // 
            this.sensorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.S_Start,
            this.S_Stop,
            this.S_AddNewSensor,
            this.S_Save,
            this.settingsToolStripMenuItem});
            this.sensorToolStripMenuItem.Name = "sensorToolStripMenuItem";
            resources.ApplyResources(this.sensorToolStripMenuItem, "sensorToolStripMenuItem");
            // 
            // S_Start
            // 
            this.S_Start.Name = "S_Start";
            resources.ApplyResources(this.S_Start, "S_Start");
            this.S_Start.Click += new System.EventHandler(this.b_start_Click);
            // 
            // S_Stop
            // 
            this.S_Stop.Name = "S_Stop";
            resources.ApplyResources(this.S_Stop, "S_Stop");
            this.S_Stop.Click += new System.EventHandler(this.b_stop_Click);
            // 
            // S_AddNewSensor
            // 
            this.S_AddNewSensor.Name = "S_AddNewSensor";
            resources.ApplyResources(this.S_AddNewSensor, "S_AddNewSensor");
            this.S_AddNewSensor.Click += new System.EventHandler(this.b_add_Click);
            // 
            // S_Save
            // 
            this.S_Save.Name = "S_Save";
            resources.ApplyResources(this.S_Save, "S_Save");
            this.S_Save.Click += new System.EventHandler(this.b_save_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1,
            this.contactToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            resources.ApplyResources(this.aboutToolStripMenuItem, "aboutToolStripMenuItem");
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            resources.ApplyResources(this.aboutToolStripMenuItem1, "aboutToolStripMenuItem1");
            // 
            // contactToolStripMenuItem
            // 
            this.contactToolStripMenuItem.Name = "contactToolStripMenuItem";
            resources.ApplyResources(this.contactToolStripMenuItem, "contactToolStripMenuItem");
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // tableLayoutPanel2
            // 
            resources.ApplyResources(this.tableLayoutPanel2, "tableLayoutPanel2");
            this.tableLayoutPanel2.Controls.Add(this.panel4, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel6, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel7, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.b_dataCollection_status);
            this.panel4.Controls.Add(this.b_stop);
            this.panel4.Controls.Add(this.b_start);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // b_dataCollection_status
            // 
            resources.ApplyResources(this.b_dataCollection_status, "b_dataCollection_status");
            this.b_dataCollection_status.Image = global::AdminPage.Properties.Resources.light_off_26;
            this.b_dataCollection_status.Name = "b_dataCollection_status";
            this.b_dataCollection_status.UseVisualStyleBackColor = true;
            // 
            // b_stop
            // 
            resources.ApplyResources(this.b_stop, "b_stop");
            this.b_stop.Image = global::AdminPage.Properties.Resources.stop_26_color;
            this.b_stop.Name = "b_stop";
            this.b_stop.UseVisualStyleBackColor = true;
            this.b_stop.Click += new System.EventHandler(this.b_stop_Click);
            // 
            // b_start
            // 
            resources.ApplyResources(this.b_start, "b_start");
            this.b_start.Image = global::AdminPage.Properties.Resources.play_26_color;
            this.b_start.Name = "b_start";
            this.b_start.UseVisualStyleBackColor = true;
            this.b_start.Click += new System.EventHandler(this.b_start_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.b_save);
            this.panel5.Controls.Add(this.b_addSensor);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // b_save
            // 
            this.b_save.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.b_save, "b_save");
            this.b_save.Image = global::AdminPage.Properties.Resources.save_26_color;
            this.b_save.Name = "b_save";
            this.b_save.UseVisualStyleBackColor = false;
            this.b_save.Click += new System.EventHandler(this.b_save_Click);
            // 
            // b_addSensor
            // 
            resources.ApplyResources(this.b_addSensor, "b_addSensor");
            this.b_addSensor.Image = global::AdminPage.Properties.Resources.add_26_color;
            this.b_addSensor.Name = "b_addSensor";
            this.b_addSensor.UseVisualStyleBackColor = true;
            this.b_addSensor.Click += new System.EventHandler(this.b_add_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.splitter2);
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // label3
            // 
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // splitter2
            // 
            this.splitter2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.splitter2, "splitter2");
            this.splitter2.Name = "splitter2";
            this.splitter2.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.splitter1);
            this.panel7.Controls.Add(this.label13);
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            // 
            // splitter1
            // 
            this.splitter1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.splitter1, "splitter1");
            this.splitter1.Name = "splitter1";
            this.splitter1.TabStop = false;
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // panel_left
            // 
            resources.ApplyResources(this.panel_left, "panel_left");
            this.panel_left.Name = "panel_left";
            // 
            // panel_right
            // 
            resources.ApplyResources(this.panel_right, "panel_right");
            this.panel_right.Name = "panel_right";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            resources.ApplyResources(this.splitContainer1, "splitContainer1");
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.listView1_thp);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.sPortNumber);
            this.splitContainer1.Panel2.Controls.Add(this.l_port);
            this.splitContainer1.Panel2.Controls.Add(this.sIPAddress);
            this.splitContainer1.Panel2.Controls.Add(this.l_ipAddress);
            this.splitContainer1.Panel2.Controls.Add(this.s_p250HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p250HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p250LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p250LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.particle250);
            this.splitContainer1.Panel2.Controls.Add(this.l_p25);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.dateTimePicker2);
            this.splitContainer1.Panel2.Controls.Add(this.dateTimePicker1);
            this.splitContainer1.Panel2.Controls.Add(this.button1);
            this.splitContainer1.Panel2.Controls.Add(this.sID);
            this.splitContainer1.Panel2.Controls.Add(this.l_zone);
            this.splitContainer1.Panel2.Controls.Add(this.sZone);
            this.splitContainer1.Panel2.Controls.Add(this.s_p100HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p100HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p100LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p100LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p50HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p50HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p50LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p50LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p30HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p30HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p30LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p30LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p10HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p10HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p10LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p10LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p05HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p05HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p05LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p05LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p01HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p03HigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p01HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p03HigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p01LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p03LowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_p01LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_p03LowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_hLowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_hLowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_hHigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_hHigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_tLowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_tLowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.s_tHigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.s_tHigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.particle100);
            this.splitContainer1.Panel2.Controls.Add(this.particle50);
            this.splitContainer1.Panel2.Controls.Add(this.particle30);
            this.splitContainer1.Panel2.Controls.Add(this.particle10);
            this.splitContainer1.Panel2.Controls.Add(this.l_p100Usage);
            this.splitContainer1.Panel2.Controls.Add(this.l_p5Usage);
            this.splitContainer1.Panel2.Controls.Add(this.l_p30Usage);
            this.splitContainer1.Panel2.Controls.Add(this.l_p10Usage);
            this.splitContainer1.Panel2.Controls.Add(this.l_p05Usage);
            this.splitContainer1.Panel2.Controls.Add(this.l_p01);
            this.splitContainer1.Panel2.Controls.Add(this.particle05);
            this.splitContainer1.Panel2.Controls.Add(this.particle01);
            this.splitContainer1.Panel2.Controls.Add(this.l_p03Usage);
            this.splitContainer1.Panel2.Controls.Add(this.particle03);
            this.splitContainer1.Panel2.Controls.Add(this.l_hUsage);
            this.splitContainer1.Panel2.Controls.Add(this.humidity);
            this.splitContainer1.Panel2.Controls.Add(this.l_tUsage);
            this.splitContainer1.Panel2.Controls.Add(this.temperature);
            this.splitContainer1.Panel2.Controls.Add(this.l_sHigherLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.l_sHigherLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.l_sLowerLimit2);
            this.splitContainer1.Panel2.Controls.Add(this.l_sLowerLimit1);
            this.splitContainer1.Panel2.Controls.Add(this.l_sUsage);
            this.splitContainer1.Panel2.Controls.Add(this.l_sDescription);
            this.splitContainer1.Panel2.Controls.Add(this.l_sLocation);
            this.splitContainer1.Panel2.Controls.Add(this.l_sName);
            this.splitContainer1.Panel2.Controls.Add(this.l_sID);
            this.splitContainer1.Panel2.Controls.Add(this.sDescription);
            this.splitContainer1.Panel2.Controls.Add(this.sLocation);
            this.splitContainer1.Panel2.Controls.Add(this.sName);
            // 
            // listView1_thp
            // 
            this.listView1_thp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader0,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader5,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader6});
            resources.ApplyResources(this.listView1_thp, "listView1_thp");
            this.listView1_thp.FullRowSelect = true;
            this.listView1_thp.HideSelection = false;
            this.listView1_thp.MultiSelect = false;
            this.listView1_thp.Name = "listView1_thp";
            this.listView1_thp.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listView1_thp.UseCompatibleStateImageBehavior = false;
            this.listView1_thp.View = System.Windows.Forms.View.Details;
            this.listView1_thp.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader0
            // 
            resources.ApplyResources(this.columnHeader0, "columnHeader0");
            // 
            // columnHeader1
            // 
            resources.ApplyResources(this.columnHeader1, "columnHeader1");
            // 
            // columnHeader2
            // 
            resources.ApplyResources(this.columnHeader2, "columnHeader2");
            // 
            // columnHeader5
            // 
            resources.ApplyResources(this.columnHeader5, "columnHeader5");
            // 
            // columnHeader3
            // 
            resources.ApplyResources(this.columnHeader3, "columnHeader3");
            // 
            // columnHeader4
            // 
            resources.ApplyResources(this.columnHeader4, "columnHeader4");
            // 
            // columnHeader6
            // 
            resources.ApplyResources(this.columnHeader6, "columnHeader6");
            // 
            // sPortNumber
            // 
            resources.ApplyResources(this.sPortNumber, "sPortNumber");
            this.sPortNumber.Name = "sPortNumber";
            // 
            // l_port
            // 
            resources.ApplyResources(this.l_port, "l_port");
            this.l_port.Name = "l_port";
            // 
            // sIPAddress
            // 
            resources.ApplyResources(this.sIPAddress, "sIPAddress");
            this.sIPAddress.Name = "sIPAddress";
            // 
            // l_ipAddress
            // 
            resources.ApplyResources(this.l_ipAddress, "l_ipAddress");
            this.l_ipAddress.Name = "l_ipAddress";
            // 
            // s_p250HigherLimit2
            // 
            resources.ApplyResources(this.s_p250HigherLimit2, "s_p250HigherLimit2");
            this.s_p250HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p250HigherLimit2.Name = "s_p250HigherLimit2";
            // 
            // s_p250HigherLimit1
            // 
            resources.ApplyResources(this.s_p250HigherLimit1, "s_p250HigherLimit1");
            this.s_p250HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p250HigherLimit1.Name = "s_p250HigherLimit1";
            // 
            // s_p250LowerLimit2
            // 
            resources.ApplyResources(this.s_p250LowerLimit2, "s_p250LowerLimit2");
            this.s_p250LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p250LowerLimit2.Name = "s_p250LowerLimit2";
            // 
            // s_p250LowerLimit1
            // 
            resources.ApplyResources(this.s_p250LowerLimit1, "s_p250LowerLimit1");
            this.s_p250LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p250LowerLimit1.Name = "s_p250LowerLimit1";
            // 
            // particle250
            // 
            resources.ApplyResources(this.particle250, "particle250");
            this.particle250.Name = "particle250";
            this.particle250.UseVisualStyleBackColor = true;
            this.particle250.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // l_p25
            // 
            this.l_p25.AutoEllipsis = true;
            resources.ApplyResources(this.l_p25, "l_p25");
            this.l_p25.Name = "l_p25";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // dateTimePicker2
            // 
            resources.ApplyResources(this.dateTimePicker2, "dateTimePicker2");
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.MaxDate = new System.DateTime(2200, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Value = new System.DateTime(2021, 3, 30, 0, 0, 0, 0);
            // 
            // dateTimePicker1
            // 
            resources.ApplyResources(this.dateTimePicker1, "dateTimePicker1");
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.MaxDate = new System.DateTime(2200, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Value = new System.DateTime(2021, 3, 30, 0, 0, 0, 0);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.DownloadToExcel_Click);
            // 
            // sID
            // 
            resources.ApplyResources(this.sID, "sID");
            this.sID.Name = "sID";
            this.sID.ReadOnly = true;
            // 
            // l_zone
            // 
            resources.ApplyResources(this.l_zone, "l_zone");
            this.l_zone.Name = "l_zone";
            // 
            // sZone
            // 
            resources.ApplyResources(this.sZone, "sZone");
            this.sZone.Name = "sZone";
            // 
            // s_p100HigherLimit2
            // 
            resources.ApplyResources(this.s_p100HigherLimit2, "s_p100HigherLimit2");
            this.s_p100HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p100HigherLimit2.Name = "s_p100HigherLimit2";
            // 
            // s_p100HigherLimit1
            // 
            resources.ApplyResources(this.s_p100HigherLimit1, "s_p100HigherLimit1");
            this.s_p100HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p100HigherLimit1.Name = "s_p100HigherLimit1";
            // 
            // s_p100LowerLimit2
            // 
            resources.ApplyResources(this.s_p100LowerLimit2, "s_p100LowerLimit2");
            this.s_p100LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p100LowerLimit2.Name = "s_p100LowerLimit2";
            // 
            // s_p100LowerLimit1
            // 
            resources.ApplyResources(this.s_p100LowerLimit1, "s_p100LowerLimit1");
            this.s_p100LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p100LowerLimit1.Name = "s_p100LowerLimit1";
            // 
            // s_p50HigherLimit2
            // 
            resources.ApplyResources(this.s_p50HigherLimit2, "s_p50HigherLimit2");
            this.s_p50HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p50HigherLimit2.Name = "s_p50HigherLimit2";
            // 
            // s_p50HigherLimit1
            // 
            resources.ApplyResources(this.s_p50HigherLimit1, "s_p50HigherLimit1");
            this.s_p50HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p50HigherLimit1.Name = "s_p50HigherLimit1";
            // 
            // s_p50LowerLimit2
            // 
            resources.ApplyResources(this.s_p50LowerLimit2, "s_p50LowerLimit2");
            this.s_p50LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p50LowerLimit2.Name = "s_p50LowerLimit2";
            // 
            // s_p50LowerLimit1
            // 
            resources.ApplyResources(this.s_p50LowerLimit1, "s_p50LowerLimit1");
            this.s_p50LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p50LowerLimit1.Name = "s_p50LowerLimit1";
            // 
            // s_p30HigherLimit2
            // 
            resources.ApplyResources(this.s_p30HigherLimit2, "s_p30HigherLimit2");
            this.s_p30HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p30HigherLimit2.Name = "s_p30HigherLimit2";
            // 
            // s_p30HigherLimit1
            // 
            resources.ApplyResources(this.s_p30HigherLimit1, "s_p30HigherLimit1");
            this.s_p30HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p30HigherLimit1.Name = "s_p30HigherLimit1";
            // 
            // s_p30LowerLimit2
            // 
            resources.ApplyResources(this.s_p30LowerLimit2, "s_p30LowerLimit2");
            this.s_p30LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p30LowerLimit2.Name = "s_p30LowerLimit2";
            // 
            // s_p30LowerLimit1
            // 
            resources.ApplyResources(this.s_p30LowerLimit1, "s_p30LowerLimit1");
            this.s_p30LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p30LowerLimit1.Name = "s_p30LowerLimit1";
            // 
            // s_p10HigherLimit2
            // 
            resources.ApplyResources(this.s_p10HigherLimit2, "s_p10HigherLimit2");
            this.s_p10HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p10HigherLimit2.Name = "s_p10HigherLimit2";
            // 
            // s_p10HigherLimit1
            // 
            resources.ApplyResources(this.s_p10HigherLimit1, "s_p10HigherLimit1");
            this.s_p10HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p10HigherLimit1.Name = "s_p10HigherLimit1";
            // 
            // s_p10LowerLimit2
            // 
            resources.ApplyResources(this.s_p10LowerLimit2, "s_p10LowerLimit2");
            this.s_p10LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p10LowerLimit2.Name = "s_p10LowerLimit2";
            // 
            // s_p10LowerLimit1
            // 
            resources.ApplyResources(this.s_p10LowerLimit1, "s_p10LowerLimit1");
            this.s_p10LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p10LowerLimit1.Name = "s_p10LowerLimit1";
            // 
            // s_p05HigherLimit2
            // 
            resources.ApplyResources(this.s_p05HigherLimit2, "s_p05HigherLimit2");
            this.s_p05HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p05HigherLimit2.Name = "s_p05HigherLimit2";
            // 
            // s_p05HigherLimit1
            // 
            resources.ApplyResources(this.s_p05HigherLimit1, "s_p05HigherLimit1");
            this.s_p05HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p05HigherLimit1.Name = "s_p05HigherLimit1";
            // 
            // s_p05LowerLimit2
            // 
            resources.ApplyResources(this.s_p05LowerLimit2, "s_p05LowerLimit2");
            this.s_p05LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p05LowerLimit2.Name = "s_p05LowerLimit2";
            // 
            // s_p05LowerLimit1
            // 
            resources.ApplyResources(this.s_p05LowerLimit1, "s_p05LowerLimit1");
            this.s_p05LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p05LowerLimit1.Name = "s_p05LowerLimit1";
            // 
            // s_p01HigherLimit2
            // 
            resources.ApplyResources(this.s_p01HigherLimit2, "s_p01HigherLimit2");
            this.s_p01HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p01HigherLimit2.Name = "s_p01HigherLimit2";
            // 
            // s_p03HigherLimit2
            // 
            resources.ApplyResources(this.s_p03HigherLimit2, "s_p03HigherLimit2");
            this.s_p03HigherLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p03HigherLimit2.Name = "s_p03HigherLimit2";
            // 
            // s_p01HigherLimit1
            // 
            resources.ApplyResources(this.s_p01HigherLimit1, "s_p01HigherLimit1");
            this.s_p01HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p01HigherLimit1.Name = "s_p01HigherLimit1";
            // 
            // s_p03HigherLimit1
            // 
            resources.ApplyResources(this.s_p03HigherLimit1, "s_p03HigherLimit1");
            this.s_p03HigherLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p03HigherLimit1.Name = "s_p03HigherLimit1";
            // 
            // s_p01LowerLimit2
            // 
            resources.ApplyResources(this.s_p01LowerLimit2, "s_p01LowerLimit2");
            this.s_p01LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p01LowerLimit2.Name = "s_p01LowerLimit2";
            // 
            // s_p03LowerLimit2
            // 
            resources.ApplyResources(this.s_p03LowerLimit2, "s_p03LowerLimit2");
            this.s_p03LowerLimit2.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p03LowerLimit2.Name = "s_p03LowerLimit2";
            // 
            // s_p01LowerLimit1
            // 
            resources.ApplyResources(this.s_p01LowerLimit1, "s_p01LowerLimit1");
            this.s_p01LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p01LowerLimit1.Name = "s_p01LowerLimit1";
            // 
            // s_p03LowerLimit1
            // 
            resources.ApplyResources(this.s_p03LowerLimit1, "s_p03LowerLimit1");
            this.s_p03LowerLimit1.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.s_p03LowerLimit1.Name = "s_p03LowerLimit1";
            // 
            // s_hLowerLimit2
            // 
            this.s_hLowerLimit2.AllowDrop = true;
            this.s_hLowerLimit2.DecimalPlaces = 2;
            resources.ApplyResources(this.s_hLowerLimit2, "s_hLowerLimit2");
            this.s_hLowerLimit2.Name = "s_hLowerLimit2";
            // 
            // s_hLowerLimit1
            // 
            this.s_hLowerLimit1.DecimalPlaces = 2;
            resources.ApplyResources(this.s_hLowerLimit1, "s_hLowerLimit1");
            this.s_hLowerLimit1.Name = "s_hLowerLimit1";
            // 
            // s_hHigherLimit2
            // 
            this.s_hHigherLimit2.AllowDrop = true;
            this.s_hHigherLimit2.DecimalPlaces = 2;
            resources.ApplyResources(this.s_hHigherLimit2, "s_hHigherLimit2");
            this.s_hHigherLimit2.Name = "s_hHigherLimit2";
            // 
            // s_hHigherLimit1
            // 
            this.s_hHigherLimit1.AllowDrop = true;
            this.s_hHigherLimit1.DecimalPlaces = 2;
            resources.ApplyResources(this.s_hHigherLimit1, "s_hHigherLimit1");
            this.s_hHigherLimit1.Name = "s_hHigherLimit1";
            // 
            // s_tLowerLimit2
            // 
            this.s_tLowerLimit2.AllowDrop = true;
            this.s_tLowerLimit2.DecimalPlaces = 2;
            resources.ApplyResources(this.s_tLowerLimit2, "s_tLowerLimit2");
            this.s_tLowerLimit2.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.s_tLowerLimit2.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            -2147483648});
            this.s_tLowerLimit2.Name = "s_tLowerLimit2";
            // 
            // s_tLowerLimit1
            // 
            this.s_tLowerLimit1.DecimalPlaces = 2;
            resources.ApplyResources(this.s_tLowerLimit1, "s_tLowerLimit1");
            this.s_tLowerLimit1.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.s_tLowerLimit1.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            -2147483648});
            this.s_tLowerLimit1.Name = "s_tLowerLimit1";
            // 
            // s_tHigherLimit2
            // 
            this.s_tHigherLimit2.AllowDrop = true;
            this.s_tHigherLimit2.DecimalPlaces = 2;
            resources.ApplyResources(this.s_tHigherLimit2, "s_tHigherLimit2");
            this.s_tHigherLimit2.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.s_tHigherLimit2.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            -2147483648});
            this.s_tHigherLimit2.Name = "s_tHigherLimit2";
            // 
            // s_tHigherLimit1
            // 
            this.s_tHigherLimit1.AllowDrop = true;
            this.s_tHigherLimit1.DecimalPlaces = 2;
            resources.ApplyResources(this.s_tHigherLimit1, "s_tHigherLimit1");
            this.s_tHigherLimit1.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.s_tHigherLimit1.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            -2147483648});
            this.s_tHigherLimit1.Name = "s_tHigherLimit1";
            // 
            // particle100
            // 
            resources.ApplyResources(this.particle100, "particle100");
            this.particle100.Name = "particle100";
            this.particle100.UseVisualStyleBackColor = true;
            this.particle100.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // particle50
            // 
            resources.ApplyResources(this.particle50, "particle50");
            this.particle50.Name = "particle50";
            this.particle50.UseVisualStyleBackColor = true;
            this.particle50.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // particle30
            // 
            resources.ApplyResources(this.particle30, "particle30");
            this.particle30.Name = "particle30";
            this.particle30.UseVisualStyleBackColor = true;
            this.particle30.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // particle10
            // 
            resources.ApplyResources(this.particle10, "particle10");
            this.particle10.Name = "particle10";
            this.particle10.UseVisualStyleBackColor = true;
            this.particle10.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // l_p100Usage
            // 
            this.l_p100Usage.AutoEllipsis = true;
            resources.ApplyResources(this.l_p100Usage, "l_p100Usage");
            this.l_p100Usage.Name = "l_p100Usage";
            // 
            // l_p5Usage
            // 
            this.l_p5Usage.AutoEllipsis = true;
            resources.ApplyResources(this.l_p5Usage, "l_p5Usage");
            this.l_p5Usage.Name = "l_p5Usage";
            // 
            // l_p30Usage
            // 
            this.l_p30Usage.AutoEllipsis = true;
            resources.ApplyResources(this.l_p30Usage, "l_p30Usage");
            this.l_p30Usage.Name = "l_p30Usage";
            // 
            // l_p10Usage
            // 
            this.l_p10Usage.AutoEllipsis = true;
            resources.ApplyResources(this.l_p10Usage, "l_p10Usage");
            this.l_p10Usage.Name = "l_p10Usage";
            // 
            // l_p05Usage
            // 
            this.l_p05Usage.AutoEllipsis = true;
            resources.ApplyResources(this.l_p05Usage, "l_p05Usage");
            this.l_p05Usage.Name = "l_p05Usage";
            // 
            // l_p01
            // 
            this.l_p01.AutoEllipsis = true;
            resources.ApplyResources(this.l_p01, "l_p01");
            this.l_p01.Name = "l_p01";
            // 
            // particle05
            // 
            resources.ApplyResources(this.particle05, "particle05");
            this.particle05.Name = "particle05";
            this.particle05.UseVisualStyleBackColor = true;
            this.particle05.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // particle01
            // 
            resources.ApplyResources(this.particle01, "particle01");
            this.particle01.Name = "particle01";
            this.particle01.UseVisualStyleBackColor = true;
            this.particle01.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // l_p03Usage
            // 
            this.l_p03Usage.AutoEllipsis = true;
            resources.ApplyResources(this.l_p03Usage, "l_p03Usage");
            this.l_p03Usage.Name = "l_p03Usage";
            // 
            // particle03
            // 
            resources.ApplyResources(this.particle03, "particle03");
            this.particle03.Name = "particle03";
            this.particle03.UseVisualStyleBackColor = true;
            this.particle03.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // l_hUsage
            // 
            this.l_hUsage.AutoEllipsis = true;
            resources.ApplyResources(this.l_hUsage, "l_hUsage");
            this.l_hUsage.Name = "l_hUsage";
            // 
            // humidity
            // 
            resources.ApplyResources(this.humidity, "humidity");
            this.humidity.Name = "humidity";
            this.humidity.UseVisualStyleBackColor = true;
            this.humidity.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // l_tUsage
            // 
            this.l_tUsage.AutoEllipsis = true;
            resources.ApplyResources(this.l_tUsage, "l_tUsage");
            this.l_tUsage.Name = "l_tUsage";
            // 
            // temperature
            // 
            resources.ApplyResources(this.temperature, "temperature");
            this.temperature.Name = "temperature";
            this.temperature.UseVisualStyleBackColor = true;
            this.temperature.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // l_sHigherLimit2
            // 
            resources.ApplyResources(this.l_sHigherLimit2, "l_sHigherLimit2");
            this.l_sHigherLimit2.Name = "l_sHigherLimit2";
            // 
            // l_sHigherLimit1
            // 
            resources.ApplyResources(this.l_sHigherLimit1, "l_sHigherLimit1");
            this.l_sHigherLimit1.Name = "l_sHigherLimit1";
            // 
            // l_sLowerLimit2
            // 
            resources.ApplyResources(this.l_sLowerLimit2, "l_sLowerLimit2");
            this.l_sLowerLimit2.Name = "l_sLowerLimit2";
            // 
            // l_sLowerLimit1
            // 
            resources.ApplyResources(this.l_sLowerLimit1, "l_sLowerLimit1");
            this.l_sLowerLimit1.Name = "l_sLowerLimit1";
            // 
            // l_sUsage
            // 
            resources.ApplyResources(this.l_sUsage, "l_sUsage");
            this.l_sUsage.Name = "l_sUsage";
            // 
            // l_sDescription
            // 
            resources.ApplyResources(this.l_sDescription, "l_sDescription");
            this.l_sDescription.Name = "l_sDescription";
            // 
            // l_sLocation
            // 
            resources.ApplyResources(this.l_sLocation, "l_sLocation");
            this.l_sLocation.Name = "l_sLocation";
            // 
            // l_sName
            // 
            resources.ApplyResources(this.l_sName, "l_sName");
            this.l_sName.Name = "l_sName";
            // 
            // l_sID
            // 
            resources.ApplyResources(this.l_sID, "l_sID");
            this.l_sID.Name = "l_sID";
            // 
            // sDescription
            // 
            resources.ApplyResources(this.sDescription, "sDescription");
            this.sDescription.Name = "sDescription";
            // 
            // sLocation
            // 
            resources.ApplyResources(this.sLocation, "sLocation");
            this.sLocation.Name = "sLocation";
            // 
            // sName
            // 
            resources.ApplyResources(this.sName, "sName");
            this.sName.Name = "sName";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.splitContainer2);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            resources.ApplyResources(this.splitContainer2, "splitContainer2");
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.listView2_pressure);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.label4);
            this.splitContainer2.Panel2.Controls.Add(this.dateTimePicker2_p);
            this.splitContainer2.Panel2.Controls.Add(this.dateTimePicker1_p);
            this.splitContainer2.Panel2.Controls.Add(this.button2);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchhgHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchhgHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchhgLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchhgLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmhgHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmhgHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmhgLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmhgLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchh2oHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchh2oHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchh2oLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_inchh2oLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmh2oHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmh2oHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmh2oLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_mmh2oLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_kpaHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_kpaHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_kpaLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_kpaLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_mbarLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_hpaLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_mbarLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_hpaLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_mbarHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_mbarHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_hpaHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_hpaHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_paLowerLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_paLowerLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.s_paHigherLimit2);
            this.splitContainer2.Panel2.Controls.Add(this.s_paHigherLimit1);
            this.splitContainer2.Panel2.Controls.Add(this.label9);
            this.splitContainer2.Panel2.Controls.Add(this.label10);
            this.splitContainer2.Panel2.Controls.Add(this.label11);
            this.splitContainer2.Panel2.Controls.Add(this.label12);
            this.splitContainer2.Panel2.Controls.Add(this.label1);
            this.splitContainer2.Panel2.Controls.Add(this.label14);
            this.splitContainer2.Panel2.Controls.Add(this.label15);
            this.splitContainer2.Panel2.Controls.Add(this.label16);
            this.splitContainer2.Panel2.Controls.Add(this.sID_p);
            this.splitContainer2.Panel2.Controls.Add(this.label8);
            this.splitContainer2.Panel2.Controls.Add(this.sZone_p);
            this.splitContainer2.Panel2.Controls.Add(this.inchhg);
            this.splitContainer2.Panel2.Controls.Add(this.mmhg);
            this.splitContainer2.Panel2.Controls.Add(this.inchh2o);
            this.splitContainer2.Panel2.Controls.Add(this.mmh2o);
            this.splitContainer2.Panel2.Controls.Add(this.mbar);
            this.splitContainer2.Panel2.Controls.Add(this.kpa);
            this.splitContainer2.Panel2.Controls.Add(this.hpa);
            this.splitContainer2.Panel2.Controls.Add(this.pa);
            this.splitContainer2.Panel2.Controls.Add(this.label18);
            this.splitContainer2.Panel2.Controls.Add(this.label19);
            this.splitContainer2.Panel2.Controls.Add(this.label20);
            this.splitContainer2.Panel2.Controls.Add(this.label21);
            this.splitContainer2.Panel2.Controls.Add(this.label22);
            this.splitContainer2.Panel2.Controls.Add(this.label23);
            this.splitContainer2.Panel2.Controls.Add(this.label24);
            this.splitContainer2.Panel2.Controls.Add(this.label25);
            this.splitContainer2.Panel2.Controls.Add(this.label26);
            this.splitContainer2.Panel2.Controls.Add(this.sDescription_p);
            this.splitContainer2.Panel2.Controls.Add(this.sLocation_p);
            this.splitContainer2.Panel2.Controls.Add(this.sName_p);
            // 
            // listView2_pressure
            // 
            this.listView2_pressure.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13});
            resources.ApplyResources(this.listView2_pressure, "listView2_pressure");
            this.listView2_pressure.FullRowSelect = true;
            this.listView2_pressure.HideSelection = false;
            this.listView2_pressure.MultiSelect = false;
            this.listView2_pressure.Name = "listView2_pressure";
            this.listView2_pressure.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.listView2_pressure.UseCompatibleStateImageBehavior = false;
            this.listView2_pressure.View = System.Windows.Forms.View.Details;
            this.listView2_pressure.SelectedIndexChanged += new System.EventHandler(this.listView2_pressure_SelectedIndexChanged);
            // 
            // columnHeader7
            // 
            resources.ApplyResources(this.columnHeader7, "columnHeader7");
            // 
            // columnHeader8
            // 
            resources.ApplyResources(this.columnHeader8, "columnHeader8");
            // 
            // columnHeader9
            // 
            resources.ApplyResources(this.columnHeader9, "columnHeader9");
            // 
            // columnHeader10
            // 
            resources.ApplyResources(this.columnHeader10, "columnHeader10");
            // 
            // columnHeader11
            // 
            resources.ApplyResources(this.columnHeader11, "columnHeader11");
            // 
            // columnHeader12
            // 
            resources.ApplyResources(this.columnHeader12, "columnHeader12");
            // 
            // columnHeader13
            // 
            resources.ApplyResources(this.columnHeader13, "columnHeader13");
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // dateTimePicker2_p
            // 
            resources.ApplyResources(this.dateTimePicker2_p, "dateTimePicker2_p");
            this.dateTimePicker2_p.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2_p.MaxDate = new System.DateTime(2200, 12, 31, 0, 0, 0, 0);
            this.dateTimePicker2_p.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2_p.Name = "dateTimePicker2_p";
            this.dateTimePicker2_p.Value = new System.DateTime(2021, 1, 1, 0, 0, 0, 0);
            // 
            // dateTimePicker1_p
            // 
            resources.ApplyResources(this.dateTimePicker1_p, "dateTimePicker1_p");
            this.dateTimePicker1_p.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1_p.MaxDate = new System.DateTime(2300, 12, 31, 0, 0, 0, 0);
            this.dateTimePicker1_p.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1_p.Name = "dateTimePicker1_p";
            this.dateTimePicker1_p.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.DownloadToExcel_Click);
            // 
            // s_inchhgHigherLimit2
            // 
            this.s_inchhgHigherLimit2.DecimalPlaces = 3;
            this.s_inchhgHigherLimit2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchhgHigherLimit2, "s_inchhgHigherLimit2");
            this.s_inchhgHigherLimit2.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            131072});
            this.s_inchhgHigherLimit2.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            -2147352576});
            this.s_inchhgHigherLimit2.Name = "s_inchhgHigherLimit2";
            // 
            // s_inchhgHigherLimit1
            // 
            this.s_inchhgHigherLimit1.DecimalPlaces = 3;
            this.s_inchhgHigherLimit1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchhgHigherLimit1, "s_inchhgHigherLimit1");
            this.s_inchhgHigherLimit1.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            131072});
            this.s_inchhgHigherLimit1.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            -2147352576});
            this.s_inchhgHigherLimit1.Name = "s_inchhgHigherLimit1";
            // 
            // s_inchhgLowerLimit2
            // 
            this.s_inchhgLowerLimit2.DecimalPlaces = 3;
            this.s_inchhgLowerLimit2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchhgLowerLimit2, "s_inchhgLowerLimit2");
            this.s_inchhgLowerLimit2.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            131072});
            this.s_inchhgLowerLimit2.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            -2147352576});
            this.s_inchhgLowerLimit2.Name = "s_inchhgLowerLimit2";
            // 
            // s_inchhgLowerLimit1
            // 
            this.s_inchhgLowerLimit1.DecimalPlaces = 3;
            this.s_inchhgLowerLimit1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchhgLowerLimit1, "s_inchhgLowerLimit1");
            this.s_inchhgLowerLimit1.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            131072});
            this.s_inchhgLowerLimit1.Minimum = new decimal(new int[] {
            15,
            0,
            0,
            -2147352576});
            this.s_inchhgLowerLimit1.Name = "s_inchhgLowerLimit1";
            // 
            // s_mmhgHigherLimit2
            // 
            this.s_mmhgHigherLimit2.DecimalPlaces = 3;
            this.s_mmhgHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mmhgHigherLimit2, "s_mmhgHigherLimit2");
            this.s_mmhgHigherLimit2.Maximum = new decimal(new int[] {
            375,
            0,
            0,
            131072});
            this.s_mmhgHigherLimit2.Minimum = new decimal(new int[] {
            375,
            0,
            0,
            -2147352576});
            this.s_mmhgHigherLimit2.Name = "s_mmhgHigherLimit2";
            // 
            // s_mmhgHigherLimit1
            // 
            this.s_mmhgHigherLimit1.DecimalPlaces = 3;
            this.s_mmhgHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mmhgHigherLimit1, "s_mmhgHigherLimit1");
            this.s_mmhgHigherLimit1.Maximum = new decimal(new int[] {
            375,
            0,
            0,
            131072});
            this.s_mmhgHigherLimit1.Minimum = new decimal(new int[] {
            375,
            0,
            0,
            -2147352576});
            this.s_mmhgHigherLimit1.Name = "s_mmhgHigherLimit1";
            // 
            // s_mmhgLowerLimit2
            // 
            this.s_mmhgLowerLimit2.DecimalPlaces = 3;
            this.s_mmhgLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mmhgLowerLimit2, "s_mmhgLowerLimit2");
            this.s_mmhgLowerLimit2.Maximum = new decimal(new int[] {
            375,
            0,
            0,
            131072});
            this.s_mmhgLowerLimit2.Minimum = new decimal(new int[] {
            375,
            0,
            0,
            -2147352576});
            this.s_mmhgLowerLimit2.Name = "s_mmhgLowerLimit2";
            // 
            // s_mmhgLowerLimit1
            // 
            this.s_mmhgLowerLimit1.DecimalPlaces = 3;
            this.s_mmhgLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mmhgLowerLimit1, "s_mmhgLowerLimit1");
            this.s_mmhgLowerLimit1.Maximum = new decimal(new int[] {
            375,
            0,
            0,
            131072});
            this.s_mmhgLowerLimit1.Minimum = new decimal(new int[] {
            375,
            0,
            0,
            -2147352576});
            this.s_mmhgLowerLimit1.Name = "s_mmhgLowerLimit1";
            // 
            // s_inchh2oHigherLimit2
            // 
            this.s_inchh2oHigherLimit2.DecimalPlaces = 3;
            this.s_inchh2oHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchh2oHigherLimit2, "s_inchh2oHigherLimit2");
            this.s_inchh2oHigherLimit2.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.s_inchh2oHigherLimit2.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.s_inchh2oHigherLimit2.Name = "s_inchh2oHigherLimit2";
            // 
            // s_inchh2oHigherLimit1
            // 
            this.s_inchh2oHigherLimit1.DecimalPlaces = 3;
            this.s_inchh2oHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchh2oHigherLimit1, "s_inchh2oHigherLimit1");
            this.s_inchh2oHigherLimit1.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.s_inchh2oHigherLimit1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.s_inchh2oHigherLimit1.Name = "s_inchh2oHigherLimit1";
            // 
            // s_inchh2oLowerLimit2
            // 
            this.s_inchh2oLowerLimit2.DecimalPlaces = 3;
            this.s_inchh2oLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchh2oLowerLimit2, "s_inchh2oLowerLimit2");
            this.s_inchh2oLowerLimit2.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.s_inchh2oLowerLimit2.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.s_inchh2oLowerLimit2.Name = "s_inchh2oLowerLimit2";
            // 
            // s_inchh2oLowerLimit1
            // 
            this.s_inchh2oLowerLimit1.DecimalPlaces = 3;
            this.s_inchh2oLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_inchh2oLowerLimit1, "s_inchh2oLowerLimit1");
            this.s_inchh2oLowerLimit1.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.s_inchh2oLowerLimit1.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            this.s_inchh2oLowerLimit1.Name = "s_inchh2oLowerLimit1";
            // 
            // s_mmh2oHigherLimit2
            // 
            this.s_mmh2oHigherLimit2.DecimalPlaces = 2;
            this.s_mmh2oHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.s_mmh2oHigherLimit2, "s_mmh2oHigherLimit2");
            this.s_mmh2oHigherLimit2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.s_mmh2oHigherLimit2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.s_mmh2oHigherLimit2.Name = "s_mmh2oHigherLimit2";
            // 
            // s_mmh2oHigherLimit1
            // 
            this.s_mmh2oHigherLimit1.DecimalPlaces = 2;
            this.s_mmh2oHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.s_mmh2oHigherLimit1, "s_mmh2oHigherLimit1");
            this.s_mmh2oHigherLimit1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.s_mmh2oHigherLimit1.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.s_mmh2oHigherLimit1.Name = "s_mmh2oHigherLimit1";
            // 
            // s_mmh2oLowerLimit2
            // 
            this.s_mmh2oLowerLimit2.DecimalPlaces = 2;
            this.s_mmh2oLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.s_mmh2oLowerLimit2, "s_mmh2oLowerLimit2");
            this.s_mmh2oLowerLimit2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.s_mmh2oLowerLimit2.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.s_mmh2oLowerLimit2.Name = "s_mmh2oLowerLimit2";
            // 
            // s_mmh2oLowerLimit1
            // 
            this.s_mmh2oLowerLimit1.DecimalPlaces = 2;
            this.s_mmh2oLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.s_mmh2oLowerLimit1, "s_mmh2oLowerLimit1");
            this.s_mmh2oLowerLimit1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.s_mmh2oLowerLimit1.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            -2147483648});
            this.s_mmh2oLowerLimit1.Name = "s_mmh2oLowerLimit1";
            // 
            // s_kpaHigherLimit2
            // 
            this.s_kpaHigherLimit2.DecimalPlaces = 3;
            this.s_kpaHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_kpaHigherLimit2, "s_kpaHigherLimit2");
            this.s_kpaHigherLimit2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.s_kpaHigherLimit2.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147418112});
            this.s_kpaHigherLimit2.Name = "s_kpaHigherLimit2";
            // 
            // s_kpaHigherLimit1
            // 
            this.s_kpaHigherLimit1.DecimalPlaces = 3;
            this.s_kpaHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_kpaHigherLimit1, "s_kpaHigherLimit1");
            this.s_kpaHigherLimit1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.s_kpaHigherLimit1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147418112});
            this.s_kpaHigherLimit1.Name = "s_kpaHigherLimit1";
            // 
            // s_kpaLowerLimit2
            // 
            this.s_kpaLowerLimit2.DecimalPlaces = 3;
            this.s_kpaLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_kpaLowerLimit2, "s_kpaLowerLimit2");
            this.s_kpaLowerLimit2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.s_kpaLowerLimit2.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147418112});
            this.s_kpaLowerLimit2.Name = "s_kpaLowerLimit2";
            // 
            // s_kpaLowerLimit1
            // 
            this.s_kpaLowerLimit1.DecimalPlaces = 3;
            this.s_kpaLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_kpaLowerLimit1, "s_kpaLowerLimit1");
            this.s_kpaLowerLimit1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.s_kpaLowerLimit1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147418112});
            this.s_kpaLowerLimit1.Name = "s_kpaLowerLimit1";
            // 
            // s_mbarLowerLimit2
            // 
            this.s_mbarLowerLimit2.AllowDrop = true;
            this.s_mbarLowerLimit2.DecimalPlaces = 3;
            this.s_mbarLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mbarLowerLimit2, "s_mbarLowerLimit2");
            this.s_mbarLowerLimit2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_mbarLowerLimit2.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_mbarLowerLimit2.Name = "s_mbarLowerLimit2";
            // 
            // s_hpaLowerLimit2
            // 
            this.s_hpaLowerLimit2.AllowDrop = true;
            this.s_hpaLowerLimit2.DecimalPlaces = 3;
            this.s_hpaLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_hpaLowerLimit2, "s_hpaLowerLimit2");
            this.s_hpaLowerLimit2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_hpaLowerLimit2.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_hpaLowerLimit2.Name = "s_hpaLowerLimit2";
            // 
            // s_mbarLowerLimit1
            // 
            this.s_mbarLowerLimit1.DecimalPlaces = 3;
            this.s_mbarLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mbarLowerLimit1, "s_mbarLowerLimit1");
            this.s_mbarLowerLimit1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_mbarLowerLimit1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_mbarLowerLimit1.Name = "s_mbarLowerLimit1";
            // 
            // s_hpaLowerLimit1
            // 
            this.s_hpaLowerLimit1.DecimalPlaces = 3;
            this.s_hpaLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_hpaLowerLimit1, "s_hpaLowerLimit1");
            this.s_hpaLowerLimit1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_hpaLowerLimit1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_hpaLowerLimit1.Name = "s_hpaLowerLimit1";
            // 
            // s_mbarHigherLimit2
            // 
            this.s_mbarHigherLimit2.AllowDrop = true;
            this.s_mbarHigherLimit2.DecimalPlaces = 3;
            this.s_mbarHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mbarHigherLimit2, "s_mbarHigherLimit2");
            this.s_mbarHigherLimit2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_mbarHigherLimit2.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_mbarHigherLimit2.Name = "s_mbarHigherLimit2";
            // 
            // s_mbarHigherLimit1
            // 
            this.s_mbarHigherLimit1.AllowDrop = true;
            this.s_mbarHigherLimit1.DecimalPlaces = 3;
            this.s_mbarHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_mbarHigherLimit1, "s_mbarHigherLimit1");
            this.s_mbarHigherLimit1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_mbarHigherLimit1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_mbarHigherLimit1.Name = "s_mbarHigherLimit1";
            // 
            // s_hpaHigherLimit2
            // 
            this.s_hpaHigherLimit2.AllowDrop = true;
            this.s_hpaHigherLimit2.DecimalPlaces = 3;
            this.s_hpaHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_hpaHigherLimit2, "s_hpaHigherLimit2");
            this.s_hpaHigherLimit2.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_hpaHigherLimit2.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_hpaHigherLimit2.Name = "s_hpaHigherLimit2";
            // 
            // s_hpaHigherLimit1
            // 
            this.s_hpaHigherLimit1.AllowDrop = true;
            this.s_hpaHigherLimit1.DecimalPlaces = 3;
            this.s_hpaHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.s_hpaHigherLimit1, "s_hpaHigherLimit1");
            this.s_hpaHigherLimit1.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.s_hpaHigherLimit1.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.s_hpaHigherLimit1.Name = "s_hpaHigherLimit1";
            // 
            // s_paLowerLimit2
            // 
            this.s_paLowerLimit2.AllowDrop = true;
            this.s_paLowerLimit2.DecimalPlaces = 1;
            this.s_paLowerLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.s_paLowerLimit2, "s_paLowerLimit2");
            this.s_paLowerLimit2.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.s_paLowerLimit2.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.s_paLowerLimit2.Name = "s_paLowerLimit2";
            // 
            // s_paLowerLimit1
            // 
            this.s_paLowerLimit1.DecimalPlaces = 1;
            this.s_paLowerLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.s_paLowerLimit1, "s_paLowerLimit1");
            this.s_paLowerLimit1.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.s_paLowerLimit1.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.s_paLowerLimit1.Name = "s_paLowerLimit1";
            // 
            // s_paHigherLimit2
            // 
            this.s_paHigherLimit2.AllowDrop = true;
            this.s_paHigherLimit2.DecimalPlaces = 1;
            this.s_paHigherLimit2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.s_paHigherLimit2, "s_paHigherLimit2");
            this.s_paHigherLimit2.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.s_paHigherLimit2.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.s_paHigherLimit2.Name = "s_paHigherLimit2";
            // 
            // s_paHigherLimit1
            // 
            this.s_paHigherLimit1.AllowDrop = true;
            this.s_paHigherLimit1.DecimalPlaces = 1;
            this.s_paHigherLimit1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            resources.ApplyResources(this.s_paHigherLimit1, "s_paHigherLimit1");
            this.s_paHigherLimit1.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.s_paHigherLimit1.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.s_paHigherLimit1.Name = "s_paHigherLimit1";
            // 
            // label9
            // 
            this.label9.AutoEllipsis = true;
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            this.label10.AutoEllipsis = true;
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label11
            // 
            this.label11.AutoEllipsis = true;
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            this.label12.AutoEllipsis = true;
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label1
            // 
            this.label1.AutoEllipsis = true;
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label14
            // 
            this.label14.AutoEllipsis = true;
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // label15
            // 
            this.label15.AutoEllipsis = true;
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // label16
            // 
            this.label16.AutoEllipsis = true;
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // sID_p
            // 
            resources.ApplyResources(this.sID_p, "sID_p");
            this.sID_p.Name = "sID_p";
            this.sID_p.ReadOnly = true;
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // sZone_p
            // 
            resources.ApplyResources(this.sZone_p, "sZone_p");
            this.sZone_p.Name = "sZone_p";
            // 
            // inchhg
            // 
            resources.ApplyResources(this.inchhg, "inchhg");
            this.inchhg.Name = "inchhg";
            this.inchhg.UseVisualStyleBackColor = true;
            this.inchhg.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // mmhg
            // 
            resources.ApplyResources(this.mmhg, "mmhg");
            this.mmhg.Name = "mmhg";
            this.mmhg.UseVisualStyleBackColor = true;
            this.mmhg.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // inchh2o
            // 
            resources.ApplyResources(this.inchh2o, "inchh2o");
            this.inchh2o.Name = "inchh2o";
            this.inchh2o.UseVisualStyleBackColor = true;
            this.inchh2o.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // mmh2o
            // 
            resources.ApplyResources(this.mmh2o, "mmh2o");
            this.mmh2o.Name = "mmh2o";
            this.mmh2o.UseVisualStyleBackColor = true;
            this.mmh2o.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // mbar
            // 
            resources.ApplyResources(this.mbar, "mbar");
            this.mbar.Name = "mbar";
            this.mbar.UseVisualStyleBackColor = true;
            this.mbar.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // kpa
            // 
            resources.ApplyResources(this.kpa, "kpa");
            this.kpa.Name = "kpa";
            this.kpa.UseVisualStyleBackColor = true;
            this.kpa.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // hpa
            // 
            resources.ApplyResources(this.hpa, "hpa");
            this.hpa.Name = "hpa";
            this.hpa.UseVisualStyleBackColor = true;
            this.hpa.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // pa
            // 
            resources.ApplyResources(this.pa, "pa");
            this.pa.Name = "pa";
            this.pa.UseVisualStyleBackColor = true;
            this.pa.CheckedChanged += new System.EventHandler(this.xCheckedChanged);
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // sDescription_p
            // 
            resources.ApplyResources(this.sDescription_p, "sDescription_p");
            this.sDescription_p.Name = "sDescription_p";
            // 
            // sLocation_p
            // 
            resources.ApplyResources(this.sLocation_p, "sLocation_p");
            this.sLocation_p.Name = "sLocation_p";
            // 
            // sName_p
            // 
            resources.ApplyResources(this.sName_p, "sName_p");
            this.sName_p.Name = "sName_p";
            // 
            // pTrackerTimer
            // 
            this.pTrackerTimer.Interval = 1000;
            this.pTrackerTimer.Tick += new System.EventHandler(this.pTrackerTimer_Tick);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            resources.ApplyResources(this.settingsToolStripMenuItem, "settingsToolStripMenuItem");
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_right);
            this.Controls.Add(this.panel_left);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.s_p250HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p250LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p100LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p50LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p30LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p10LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p05LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03HigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03HigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03LowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p01LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_p03LowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_tHigherLimit1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchhgLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmhgLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_inchh2oLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mmh2oLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_kpaLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_mbarHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_hpaHigherLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paLowerLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paLowerLimit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paHigherLimit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.s_paHigherLimit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem contactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sensorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem S_Start;
        private System.Windows.Forms.ToolStripMenuItem S_Stop;
        private System.Windows.Forms.ToolStripMenuItem S_AddNewSensor;
        private System.Windows.Forms.ToolStripMenuItem S_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button b_dataCollection_status;
        private System.Windows.Forms.Button b_stop;
        private System.Windows.Forms.Button b_start;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel_left;
        private System.Windows.Forms.Panel panel_right;
        private System.Windows.Forms.Button b_save;
        private System.Windows.Forms.Button b_addSensor;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView listView1_thp;
        private System.Windows.Forms.ColumnHeader columnHeader0;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.TextBox sID;
        private System.Windows.Forms.Label l_zone;
        private System.Windows.Forms.TextBox sZone;
        private System.Windows.Forms.NumericUpDown s_p50HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p50HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p50LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p50LowerLimit1;
        private System.Windows.Forms.NumericUpDown s_p30HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p30HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p30LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p30LowerLimit1;
        private System.Windows.Forms.NumericUpDown s_p10HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p10HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p10LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p10LowerLimit1;
        private System.Windows.Forms.NumericUpDown s_p05HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p05HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p05LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p05LowerLimit1;
        private System.Windows.Forms.NumericUpDown s_p03HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p03HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p03LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p03LowerLimit1;
        private System.Windows.Forms.NumericUpDown s_hLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_hLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_hHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_hHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_tLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_tLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_tHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_tHigherLimit1;
        private System.Windows.Forms.CheckBox particle100;
        private System.Windows.Forms.CheckBox particle50;
        private System.Windows.Forms.CheckBox particle30;
        private System.Windows.Forms.CheckBox particle10;
        private System.Windows.Forms.Label l_p5Usage;
        private System.Windows.Forms.Label l_p30Usage;
        private System.Windows.Forms.Label l_p10Usage;
        private System.Windows.Forms.Label l_p05Usage;
        private System.Windows.Forms.CheckBox particle05;
        private System.Windows.Forms.Label l_p03Usage;
        private System.Windows.Forms.CheckBox particle03;
        private System.Windows.Forms.Label l_hUsage;
        private System.Windows.Forms.CheckBox humidity;
        private System.Windows.Forms.Label l_tUsage;
        private System.Windows.Forms.CheckBox temperature;
        private System.Windows.Forms.Label l_sHigherLimit2;
        private System.Windows.Forms.Label l_sHigherLimit1;
        private System.Windows.Forms.Label l_sLowerLimit2;
        private System.Windows.Forms.Label l_sLowerLimit1;
        private System.Windows.Forms.Label l_sUsage;
        private System.Windows.Forms.Label l_sDescription;
        private System.Windows.Forms.Label l_sLocation;
        private System.Windows.Forms.Label l_sName;
        private System.Windows.Forms.Label l_sID;
        private System.Windows.Forms.TextBox sDescription;
        private System.Windows.Forms.TextBox sLocation;
        private System.Windows.Forms.TextBox sName;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ListView listView2_pressure;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.TextBox sID_p;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox sZone_p;
        private System.Windows.Forms.CheckBox inchhg;
        private System.Windows.Forms.CheckBox mmhg;
        private System.Windows.Forms.CheckBox inchh2o;
        private System.Windows.Forms.CheckBox mmh2o;
        private System.Windows.Forms.CheckBox kpa;
        private System.Windows.Forms.CheckBox hpa;
        private System.Windows.Forms.CheckBox pa;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox sDescription_p;
        private System.Windows.Forms.TextBox sLocation_p;
        private System.Windows.Forms.TextBox sName_p;
        private System.Windows.Forms.NumericUpDown s_p100HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p100HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p100LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p100LowerLimit1;
        private System.Windows.Forms.Label l_p100Usage;
        private System.Windows.Forms.NumericUpDown s_inchhgHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_inchhgHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_inchhgLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_inchhgLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_mmhgHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_mmhgHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_mmhgLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_mmhgLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_inchh2oHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_inchh2oHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_inchh2oLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_inchh2oLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_mmh2oHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_mmh2oHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_mmh2oLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_mmh2oLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_kpaHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_kpaHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_kpaLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_kpaLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_hpaLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_hpaLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_hpaHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_hpaHigherLimit1;
        private System.Windows.Forms.NumericUpDown s_paLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_paLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_paHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_paHigherLimit1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2_p;
        private System.Windows.Forms.DateTimePicker dateTimePicker1_p;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown s_p01HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p01HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p01LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p01LowerLimit1;
        private System.Windows.Forms.Label l_p01;
        private System.Windows.Forms.CheckBox particle01;
        private System.Windows.Forms.NumericUpDown s_p250HigherLimit2;
        private System.Windows.Forms.NumericUpDown s_p250HigherLimit1;
        private System.Windows.Forms.NumericUpDown s_p250LowerLimit2;
        private System.Windows.Forms.NumericUpDown s_p250LowerLimit1;
        private System.Windows.Forms.CheckBox particle250;
        private System.Windows.Forms.Label l_p25;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown s_mbarLowerLimit2;
        private System.Windows.Forms.NumericUpDown s_mbarLowerLimit1;
        private System.Windows.Forms.NumericUpDown s_mbarHigherLimit2;
        private System.Windows.Forms.NumericUpDown s_mbarHigherLimit1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox mbar;
        public System.Windows.Forms.Timer pTrackerTimer;
        private System.Windows.Forms.TextBox sPortNumber;
        private System.Windows.Forms.Label l_port;
        private System.Windows.Forms.TextBox sIPAddress;
        private System.Windows.Forms.Label l_ipAddress;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
    }
}

