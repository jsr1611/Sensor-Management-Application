# Data Collection App
Data Collection App using Modbus RTU for Temperature, Humidity, and Particle data stored in MS SQL database.

